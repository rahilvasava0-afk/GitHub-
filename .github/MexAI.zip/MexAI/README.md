# Mex AI – Female JARVIS Android Assistant

Native Android app (Kotlin, Jetpack Compose + Material 3, min SDK 26 / Android 8.0, target SDK 35).
AI brain = Google Gemini REST API (no SDK, no hard-coded key).

## Build
1. Install **Android Studio Ladybug (2024.2) or newer** (JDK 17 is bundled).
2. `File > Open` this folder. Let Gradle sync (it downloads Gradle 8.9 + dependencies; internet needed).
3. Run on a device/emulator (`Run ▶`) or `Build > Build APK(s)` -> `app/build/outputs/apk/debug/app-debug.apk`.
4. CLI alternative (with Gradle 8.9 installed): `gradle wrapper && ./gradlew assembleDebug`.
5. Open the app > Settings > paste your Gemini API key (free at https://aistudio.google.com) > Test connection.

> Status: this project was written without access to an Android SDK, so it has **not been compiled yet**.
> If Gradle reports a compile error, paste it into Coding Studio (mode "Fix build error") or send it back and it will be fixed.

## Module map (`app/src/main/java/com/mex/ai`)
| File | Purpose |
|---|---|
| `Gemini.kt` | REST client (chat, image/PDF/text input, Google Search grounding for weather/news/web search) |
| `Store.kt` | AES-256 encrypted prefs: API key, settings, memory facts, notes, chat history |
| `Brain.kt` | Persona prompt, wake-word parsing, memory, routing local-commands vs Gemini, coding calls, ZIP export |
| `CommandRouter.kt` | Offline commands: open apps, torch, volume, brightness, alarms/timers, calculator, battery, media keys, YouTube search, notes |
| `Voice.kt` | SpeechRecognizer (hi-IN/en) + TextToSpeech (female voice preference, pitch tuned) |
| `WakeService.kt` | Foreground mic service: wake word "Mex" -> "Hmm Boss ❤️" -> continuous conversation |
| `MexAccessibilityService.kt` | Tap, scroll, back/home/recents, screenshot (only on your command) |
| `MexNotificationListener.kt` | Read-out of recent notifications (memory only) |
| `*Screen.kt`, `Orb.kt`, `Theme.kt` | Home, Chat, Coding Studio, Apps, Settings; animated orb; glassmorphism |

## Example voice/text commands
`Mex` · `YouTube kholo` · `flashlight on karo` · `volume badhao` · `brightness kam karo` · `screenshot lo` · `Wi-Fi settings kholo`
`Arijit Singh ka gana chalao` · `next song` · `pause karo` · `7:30 baje alarm lagao` · `10 minute timer` · `5 plus 3` · `yaad rakho meri bike ka number ...`
`note: milk lena` · `notifications padho` · `aaj ka mausam` (Gemini + Google Search) · `scroll down` · `tap 500 900`

## Android limitations (and what Mex does instead)
- **Music**: Mex opens YouTube / YouTube Music with a search for your query. It cannot auto-tap and play the first result without the Accessibility service, and background playback is controlled by the YouTube app, not Mex. Next/pause use system media keys and work with most players.
- **Wake word**: uses Android's SpeechRecognizer in a foreground service (visible notification, may beep, uses battery). It is *not* an always-on hotword engine like "Hey Google"; some OEMs kill background services unless you disable battery optimization (Settings button provided). Android 14+ requires the service to be started while the app is visible.
- **Brightness / alarms**: brightness needs the "Modify system settings" permission (Mex opens that screen); alarms/timers use the system Clock app.
- **Screenshot / tap / scroll**: need the Accessibility service enabled by you; Android blocks them on secure screens, and screenshot needs Android 9+.
- **Notifications**: need Notification-access permission. **Clipboard**: read only while the app is in the foreground (Android 10+).
- **Avatar**: the UI ships a procedural animated orb; drop an illustrated avatar image into the Home screen if you want a face.
- Gemini model names change over time; edit the model field in Settings if one is retired.
