package com.mex.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private val quick = listOf(
    "▶ YouTube" to "youtube kholo", "💬 WhatsApp" to "whatsapp kholo", "📷 Camera" to "camera kholo",
    "🔦 Torch On" to "flashlight on karo", "🔦 Torch Off" to "flashlight off karo", "🔋 Battery" to "battery kitni hai",
    "📸 Screenshot" to "screenshot lo", "⚙ Settings" to "settings kholo", "🎶 Romantic" to "romantic songs play karo",
    "⏰ Time" to "time kya hua"
)

@Composable
fun HomeScreen(vm: MexVM, openChat: () -> Unit) {
    val h = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greet = when { h < 5 -> "Shubh ratri"; h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; else -> "Good evening" }
    var input by remember { mutableStateOf("") }
    val primary = MaterialTheme.colorScheme.primary
    val status = when {
        vm.voice.listening -> "Sun rahi hoon… 🎧"
        vm.voice.speaking -> "Bol rahi hoon… (orb tap karke roko)"
        vm.busy -> "Soch rahi hoon…"
        else -> "Orb tap karo aur bolo"
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$greet, Boss", color = Color.White.copy(.7f))
        Text("Hmm Boss ❤️", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = primary)
        Spacer(Modifier.height(8.dp))
        Orb(vm.voice.listening, vm.voice.speaking, 250.dp) { vm.toggleVoice() }
        Text(status, color = Color.White.copy(.8f))
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { vm.toggleVoice() }, shape = CircleShape,
            modifier = Modifier.size(72.dp).shadow(18.dp, CircleShape, ambientColor = primary, spotColor = primary),
            contentPadding = PaddingValues(0.dp)
        ) { Text(if (vm.voice.listening) "⏹" else "🎤", fontSize = 28.sp) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(vm.continuous, { vm.continuous = it })
            Spacer(Modifier.width(8.dp))
            Text("Continuous conversation", color = Color.White.copy(.8f), fontSize = 13.sp)
        }
        if (vm.lastReply.isNotBlank()) {
            Glass(Modifier.fillMaxWidth()) {
                SelectionContainer { Text(vm.lastReply, color = Color.White) }
            }
            TextButton(onClick = openChat) { Text("Poori conversation dekho →") }
        }
        Spacer(Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(quick) { (label, cmd) -> AssistChip(onClick = { vm.send(cmd) }, label = { Text(label) }) }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), placeholder = { Text("Mex se kuch bhi poochho…") },
                singleLine = true, shape = CircleShape
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.send(input); input = "" }, enabled = !vm.busy) { Text("Send") }
        }
        Text(
            "Tip: \"Mex\" bolkar background assistant on karo (Settings).",
            fontSize = 11.sp, color = Color.White.copy(.45f), textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}
