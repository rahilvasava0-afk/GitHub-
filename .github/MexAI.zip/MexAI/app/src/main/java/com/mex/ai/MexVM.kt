package com.mex.ai

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MexVM(private val app: Application) : AndroidViewModel(app) {
    private val a = app as MexApplication
    val brain = a.brain
    val voice = a.voice
    val store = brain.store

    val messages = mutableStateListOf<Msg>().also { it.addAll(brain.hist) }
    var busy by mutableStateOf(false)
    var lastReply by mutableStateOf("")
    var continuous by mutableStateOf(false)
    var accent by mutableStateOf(store.accent)
    var codeOut by mutableStateOf("")
    var codeBusy by mutableStateOf(false)

    fun reload() { messages.clear(); messages.addAll(brain.hist) }

    fun send(text: String, attachment: Attachment? = null, speak: Boolean = false) {
        if (text.isBlank() && attachment == null) return
        if (busy) return
        messages.add(Msg("user", if (attachment != null) "📎 ${attachment.name}: $text" else text))
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val out = brain.reply(text, attachment)
            withContext(Dispatchers.Main) {
                messages.add(Msg("model", out))
                lastReply = out
                busy = false
                if (speak || continuous) voice.speak(out) { if (continuous) startListening() }
            }
        }
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun startListening() {
        if (!hasMic()) { lastReply = "Boss, mic permission do (Settings > Apps > Mex AI > Permissions)."; return }
        voice.listen(
            onResult = { send(it, speak = true) },
            onFail = { e ->
                if (e != SpeechRecognizer.ERROR_NO_MATCH && e != SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    lastReply = "Mic error ($e). Google speech service / internet check karo."
            }
        )
    }

    /** Tap orb: interrupt speech (and listen), or stop listening, or start listening. */
    fun toggleVoice() {
        when {
            voice.speaking -> { voice.stopSpeaking(); startListening() }
            voice.listening -> voice.cancelListening()
            else -> startListening()
        }
    }

    fun code(prompt: String, lang: String, mode: String) {
        if (prompt.isBlank() || codeBusy) return
        codeBusy = true
        viewModelScope.launch(Dispatchers.IO) {
            val out = try { brain.coding(prompt, lang, mode) } catch (e: Exception) { "// Error: ${e.message}" }
            withContext(Dispatchers.Main) { codeOut = out; codeBusy = false }
        }
    }

    fun clearHistory() { brain.clearHistory(); messages.clear(); lastReply = "" }
}
