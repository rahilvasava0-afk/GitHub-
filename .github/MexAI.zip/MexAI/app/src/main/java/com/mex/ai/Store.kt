package com.mex.ai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** All settings, API key, memory and notes live in AES-256 encrypted preferences. */
class Store(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "mex_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var apiKey: String get() = s("api", ""); set(v) = put("api", v)
    var model: String get() = s("model", "gemini-2.5-flash"); set(v) = put("model", v)
    var temperature: Float get() = sp.getFloat("temp", 0.9f); set(v) = sp.edit().putFloat("temp", v).apply()
    var maxTokens: Int get() = sp.getInt("tok", 2048); set(v) = sp.edit().putInt("tok", v).apply()
    var fastMode: Boolean get() = sp.getBoolean("fast", true); set(v) = sp.edit().putBoolean("fast", v).apply()
    var wakeWord: String get() = s("wake", "mex"); set(v) = put("wake", v.trim().lowercase())
    var lang: String get() = s("lang", "hi-IN"); set(v) = put("lang", v)
    var voiceName: String get() = s("voice", ""); set(v) = put("voice", v)
    var persona: String get() = s("persona", "Girlfriend"); set(v) = put("persona", v)
    var customPersona: String get() = s("cpersona", ""); set(v) = put("cpersona", v)
    var keepHistory: Boolean get() = sp.getBoolean("keep", true); set(v) = sp.edit().putBoolean("keep", v).apply()
    var accent: Int get() = sp.getInt("accent", 0); set(v) = sp.edit().putInt("accent", v).apply()
    var wakeEnabled: Boolean get() = sp.getBoolean("wakeOn", false); set(v) = sp.edit().putBoolean("wakeOn", v).apply()

    private fun list(k: String): MutableList<String> {
        val a = try { JSONArray(s(k, "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(a.length()) { a.getString(it) }
    }
    private fun saveList(k: String, l: List<String>) { put(k, JSONArray(l).toString()) }

    fun facts() = list("facts")
    fun saveFacts(l: List<String>) = saveList("facts", l)
    fun addFact(f: String) { val l = facts(); l.add(f.trim()); saveFacts(l.takeLast(60)) }
    fun notes() = list("notes")
    fun saveNotes(l: List<String>) = saveList("notes", l)
    fun addNote(n: String) { val l = notes(); l.add(0, n.trim()); saveNotes(l) }

    fun history(): MutableList<Msg> {
        val a = try { JSONArray(s("hist", "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(a.length()) { val o = a.getJSONObject(it); Msg(o.getString("r"), o.getString("t")) }
    }
    fun saveHistory(l: List<Msg>) {
        if (!keepHistory) { put("hist", "[]"); return }
        val a = JSONArray()
        l.takeLast(200).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        put("hist", a.toString())
    }
}
