package com.mex.ai

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.accessibilityservice.AccessibilityService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Handles phone-control commands locally (works offline). Returns null when the text
 * is not a command so that Gemini can answer it.
 */
class CommandRouter(private val ctx: Context, private val store: Store) {

    private val dev = linkedMapOf(
        "खोलो" to "kholo", "खोल" to "khol", "यूट्यूब" to "youtube", "यूटयूब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "चालू" to "on", "बंद" to "band", "बढ़ाओ" to "badhao", "बढाओ" to "badhao", "कम" to "kam",
        "गाना" to "gana", "गाने" to "gana", "चलाओ" to "chalao", "फ्लैशलाइट" to "flashlight",
        "टॉर्च" to "torch", "कैमरा" to "camera", "सेटिंग्स" to "settings", "सेटिंग" to "settings",
        "वॉल्यूम" to "volume", "ब्राइटनेस" to "brightness", "अगला" to "next", "रोको" to "pause",
        "बैटरी" to "battery", "स्क्रीनशॉट" to "screenshot", "वाईफाई" to "wifi", "करो" to "karo"
    )

    private fun norm(s: String): String {
        var t = s.lowercase(Locale.ROOT).trim()
        dev.forEach { (k, v) -> t = t.replace(k, v) }
        t = t.replace("wi-fi", "wifi").replace("wi fi", "wifi")
        return t.replace(Regex("[?!।,]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }

    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: Exception) { false }

    fun launchableApps(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    fun openApp(pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return launch(i)
    }

    fun handle(raw: String): String? {
        val t = norm(raw)
        if (t.isEmpty()) return null

        // ---- memory & notes ----
        Regex("^(yaad rakho|yaad rakh lo|remember( that)?)[:,]?\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(raw.trim())?.let { store.addFact(it.groupValues[3]); return "Theek hai Boss ❤️, yaad rakh liya." }
        Regex("^(note( likho| karo| kar| add)?|add note)[:,]?\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(raw.trim())?.let { store.addNote(it.groupValues[3]); return "Note save kar liya Boss 📝" }
        if (has(t, "mere notes", "notes dikhao", "my notes", "notes padho")) {
            val n = store.notes()
            return if (n.isEmpty()) "Abhi koi note nahi hai Boss." else "Aapke notes: " + n.take(5).joinToString(". ")
        }

        // ---- calculator ----
        val mt = t.replace("calculate", "").replace("calc", "").replace("plus", "+").replace("minus", "-")
            .replace("times", "*").replace("into", "*").replace("divided by", "/").replace("guna", "*")
            .replace("bhaag", "/").replace("jod", "+").replace("equals", "").replace("=", "").trim()
        if (Regex("^[0-9+\\-*/().x×÷% ]+$").matches(mt) && mt.any { it.isDigit() } && mt.any { it in "+-*/x×÷%" }) {
            try {
                val v = Calc(mt).parse()
                val out = if (v == floor(v) && abs(v) < 1e15) v.toLong().toString() else "%.6f".format(v).trimEnd('0').trimEnd('.')
                return "Answer hai $out Boss 🧮"
            } catch (e: Exception) { /* fall through */ }
        }

        // ---- device info ----
        if (has(t, "battery")) return batteryText()
        if (has(t, "device info", "phone info", "storage")) return deviceInfo()
        if (has(t, "kitne baje", "time kya", "what time", "current time"))
            return "Abhi " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + " baj rahe hain Boss ⏰"
        if (has(t, "aaj ki date", "today's date", "tarikh", "what date", "date kya"))
            return "Aaj " + SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date()) + " hai Boss 📅"

        // ---- flashlight / volume / brightness ----
        if (has(t, "flashlight", "torch")) return torch(!has(t, "off", "band", "bujha", "bandh"))
        if (has(t, "volume")) return volume(t)
        if (has(t, "brightness")) return brightness(t)

        // ---- accessibility-based automation ----
        if (has(t, "screenshot"))
            return acc("Screenshot le liya Boss 📸") {
                Build.VERSION.SDK_INT >= 28 && it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            }
        if (has(t, "back jao", "peeche jao", "go back"))
            return acc("Peeche aa gayi Boss.") { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }
        if (has(t, "home jao", "go home", "home screen"))
            return acc("Home screen par hoon Boss.") { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }
        if (has(t, "recent apps", "recents"))
            return acc("Recent apps khol diye.") { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        if (has(t, "scroll down", "neeche scroll", "niche scroll")) return acc("Scroll down kar diya.") { it.scroll(true) }
        if (has(t, "scroll up", "upar scroll")) return acc("Scroll up kar diya.") { it.scroll(false) }
        Regex("tap\\s+(\\d+)\\s+(\\d+)").find(t)?.let { m ->
            val x = m.groupValues[1].toFloat(); val y = m.groupValues[2].toFloat()
            return acc("($x, $y) par tap kar diya Boss.") { it.tap(x, y) }
        }

        // ---- media keys ----
        if (has(t, "next song", "next gana", "agla gana", "next track") || t == "next")
            return media(KeyEvent.KEYCODE_MEDIA_NEXT, "Next gana ⏭")
        if (has(t, "previous song", "pichla gana", "previous track"))
            return media(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Pichla gana ⏮")
        if (has(t, "pause", "ruko", "stop music", "gana band"))
            return media(KeyEvent.KEYCODE_MEDIA_PAUSE, "Pause kar diya ⏸")
        if (t == "resume" || t == "play karo" || t == "resume karo")
            return media(KeyEvent.KEYCODE_MEDIA_PLAY, "Play kar diya ▶")

        // ---- alarm / timer / reminder ----
        if (has(t, "alarm", "timer", "yaad dila", "remind")) return alarmOrTimer(t)

        // ---- music via YouTube / YouTube Music ----
        val playWords = listOf("chalao", "play", "bajao", "sunao", "laga do", "lagao")
        val songWords = listOf("gana", "gaana", "song", "music", "gaane", "bhajan", "ghazal")
        if (playWords.any { t.contains(it) } && (songWords.any { t.contains(it) } || t.contains("youtube"))) {
            val stop = setOf("mex", "chalao", "play", "karo", "kar", "do", "bajao", "sunao", "ka", "ke", "ki", "ko",
                "me", "par", "mein", "please", "mujhe", "laga", "lagao", "de", "youtube", "on")
            val q = t.split(" ").filter { it !in stop }.joinToString(" ").ifBlank { "trending songs" }
            val enc = Uri.encode(q)
            val uri = if (t.contains("youtube music")) "https://music.youtube.com/search?q=$enc"
            else "https://www.youtube.com/results?search_query=$enc"
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            if (!launch(Intent(i).setPackage(if (t.contains("youtube music")) "com.google.android.apps.youtube.music" else "com.google.android.youtube")))
                launch(i)
            return "\"$q\" YouTube par khol diya Boss 🎶 Bas ek gana tap karna hai."
        }

        // ---- open apps / settings ----
        if (has(t, "kholo", "khol", "open", "launch")) {
            if (t.contains("wifi")) { launch(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wi-Fi settings khol di Boss." }
            if (t.contains("bluetooth")) { launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings khol di Boss." }
            val stop = setOf("mex", "kholo", "khol", "open", "launch", "karo", "kar", "do", "please", "app", "ko", "ka", "the")
            val target = t.split(" ").filter { it !in stop }.joinToString(" ").trim()
            if (target.isEmpty()) return null
            if (target == "settings" || target == "setting") { launch(Intent(Settings.ACTION_SETTINGS)); return "Settings khol di Boss ⚙️" }
            if (target == "camera") {
                return if (launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) "Camera khol diya Boss 📷" else "Camera nahi khul paya."
            }
            val apps = launchableApps()
            val hit = apps.firstOrNull { it.first.equals(target, true) }
                ?: apps.firstOrNull { it.first.lowercase().contains(target) }
                ?: apps.firstOrNull { target.contains(it.first.lowercase()) }
            return if (hit != null && openApp(hit.second)) "${hit.first} khol diya Boss ✨"
            else "Boss, \"$target\" naam ka app nahi mila."
        }

        // ---- notifications ----
        if (has(t, "notification") && has(t, "padh", "read", "batao", "dikha", "sunao")) {
            if (!MexNotificationListener.connected) {
                launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                return "Boss, notifications padhne ke liye 'Mex AI Notifications' ko allow karo. Settings khol di hain."
            }
            val n = MexNotificationListener.recent.take(5)
            return if (n.isEmpty()) "Koi nayi notification nahi hai Boss." else "Ye rahi notifications: " + n.joinToString(". ")
        }
        return null
    }

    // ---------------- helpers ----------------
    private fun acc(ok: String, block: (MexAccessibilityService) -> Boolean): String {
        val s = MexAccessibilityService.instance
        if (s == null) {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "Boss, pehle Accessibility me 'Mex AI Automation' enable karo. Maine settings khol di hain."
        }
        return if (block(s)) ok else "Ye action nahi ho paya Boss (Android ne roka)."
    }

    private fun media(code: Int, ok: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok
    }

    private fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Boss, is phone me flashlight nahi mili."
            cm.setTorchMode(id, on)
            if (on) "Flashlight on kar di Boss 🔦" else "Flashlight band kar di Boss."
        } catch (e: Exception) { "Flashlight me dikkat aayi: ${e.message}" }
    }

    private fun volume(t: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return when {
            has(t, "full", "max") -> { am.setStreamVolume(AudioManager.STREAM_MUSIC, maxV, AudioManager.FLAG_SHOW_UI); "Volume full kar diya Boss 🔊" }
            has(t, "mute", "silent") -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Mute kar diya Boss 🔇" }
            has(t, "kam", "ghata", "down", "decrease", "dheema") -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, if (it == 0) AudioManager.FLAG_SHOW_UI else 0) }; "Volume kam kar diya Boss." }
            has(t, "badha", "increase", "up", "zyada", "tez", "loud") -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, if (it == 0) AudioManager.FLAG_SHOW_UI else 0) }; "Volume badha diya Boss 🔊" }
            else -> "Boss, volume badhana hai ya kam karna?"
        }
    }

    private fun brightness(t: String): String {
        if (!Settings.System.canWrite(ctx)) {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return "Boss, brightness badalne ke liye 'Modify system settings' allow karo. Screen khol di hai."
        }
        val cr = ctx.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val nv = when {
            has(t, "full", "max") -> 255
            has(t, "kam", "ghata", "down", "decrease", "dim") -> max(10, cur - 50)
            has(t, "badha", "increase", "up", "zyada") -> min(255, cur + 50)
            else -> return "Boss, brightness badhani hai ya kam karni?"
        }
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, nv)
        return "Brightness ${nv * 100 / 255}% kar di Boss ☀️"
    }

    private fun alarmOrTimer(t: String): String {
        val tm = Regex("(\\d+)\\s*(second|sec|minute|mins|min|ghante|ghanta|hours|hour)").find(t)
        if (tm != null && (t.contains("timer") || has(t, "baad", "later", "in ", "yaad dila", "remind"))) {
            val n = tm.groupValues[1].toInt()
            val u = tm.groupValues[2]
            val secs = if (u.startsWith("sec")) n else if (u.startsWith("min")) n * 60 else n * 3600
            val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Mex reminder").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return if (launch(i)) "Timer set kar diya Boss ⏳ ($n ${tm.groupValues[2]})" else "Timer set nahi ho paya."
        }
        var h: Int; var m = 0
        val a = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)
        val b = Regex("(\\d{1,2})\\s*(baje|am|pm|o'clock)").find(t)
        if (a != null) { h = a.groupValues[1].toInt(); m = a.groupValues[2].toInt() }
        else if (b != null) { h = b.groupValues[1].toInt() }
        else return "Boss, kitne baje ka alarm lagana hai? Jaise \"7:30 baje alarm lagao\"."
        val pmFlag = Regex("\\bpm\\b").containsMatchIn(t) || has(t, "shaam", "raat", "dopahar")
        if (pmFlag && h < 12) h += 12
        if ((Regex("\\bam\\b").containsMatchIn(t) || t.contains("subah")) && h == 12) h = 0
        if (h > 23 || m > 59) return "Ye time sahi nahi lag raha Boss."
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "Mex AI")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Alarm set kar diya Boss ⏰ %02d:%02d".format(h, m) else "Alarm set nahi ho paya."
    }

    fun batteryText(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return "Battery ${lvl * 100 / scale}% hai Boss 🔋" + if (charging) " (charge ho rahi hai)" else ""
    }

    fun deviceInfo(): String {
        val sf = StatFs(Environment.getDataDirectory().path)
        val freeGb = sf.availableBytes / 1_073_741_824.0
        return "${batteryText()}\nDevice: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nFree storage: %.1f GB".format(freeGb)
    }

    private class Calc(val s: String) {
        var p = 0
        fun parse(): Double { val v = expr(); ws(); if (p < s.length) throw IllegalArgumentException(); return v }
        fun ws() { while (p < s.length && s[p] == ' ') p++ }
        fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                if (p < s.length && (s[p] == '+' || s[p] == '-')) { val o = s[p++]; val r = term(); v = if (o == '+') v + r else v - r } else return v
            }
        }
        fun term(): Double {
            var v = factor()
            while (true) {
                ws()
                if (p < s.length && s[p] in "*/x×÷") { val o = s[p++]; val r = factor(); v = if (o == '/' || o == '÷') v / r else v * r } else return v
            }
        }
        fun factor(): Double {
            ws()
            if (p < s.length && s[p] == '-') { p++; return -factor() }
            if (p < s.length && s[p] == '(') {
                p++; val v = expr(); ws()
                if (p < s.length && s[p] == ')') p++ else throw IllegalArgumentException()
                return pct(v)
            }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (st == p) throw IllegalArgumentException()
            return pct(s.substring(st, p).toDouble())
        }
        fun pct(v: Double): Double { ws(); if (p < s.length && s[p] == '%') { p++; return v / 100 }; return v }
    }
}
