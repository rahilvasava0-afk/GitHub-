package com.mex.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Performs gestures/global actions ONLY when the user gives a command and has enabled this service. */
class MexAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: MexAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float): Boolean = gesture(Path().apply { moveTo(x, y) }, 50)

    fun scroll(down: Boolean): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels / 2f
        val h = dm.heightPixels.toFloat()
        val from = if (down) h * 0.7f else h * 0.3f
        val to = if (down) h * 0.3f else h * 0.7f
        return gesture(Path().apply { moveTo(w, from); lineTo(w, to) }, 350)
    }
}
