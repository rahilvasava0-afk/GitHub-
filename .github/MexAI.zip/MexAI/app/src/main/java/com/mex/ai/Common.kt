package com.mex.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import java.io.ByteArrayOutputStream

@Composable
fun Picker(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text("$label: $selected", maxLines = 1) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onSelect(o); open = false }) }
        }
    }
}

private val keywords = setOf(
    "fun", "val", "var", "class", "object", "interface", "override", "private", "public", "protected", "internal",
    "return", "if", "else", "when", "for", "while", "do", "try", "catch", "finally", "throw", "import", "package",
    "null", "true", "false", "this", "super", "new", "static", "final", "void", "int", "String", "def", "lambda",
    "from", "as", "in", "is", "const", "let", "function", "async", "await", "extends", "implements", "data", "sealed",
    "suspend", "companion", "enum", "print", "self", "None", "True", "False", "elif", "except", "with", "pass"
)
private val tokenRe = Regex(
    """(//[^\n]*|#[^\n]*|/\*[\s\S]*?\*/)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|\b([A-Za-z_]\w*)\b|\b(\d+(?:\.\d+)?)\b"""
)

fun highlight(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    tokenRe.findAll(code).forEach { m ->
        val color = when {
            m.groups[1] != null -> Color(0xFF6B7C93)
            m.groups[2] != null -> Color(0xFF7EE787)
            m.groups[3] != null && m.value in keywords -> Color(0xFFC792EA)
            m.groups[4] != null -> Color(0xFFFFB86C)
            else -> null
        }
        if (color != null) addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
    }
}

val codeTransformation = VisualTransformation { TransformedText(highlight(it.text), OffsetMapping.Identity) }

fun bitmapAttachment(b: Bitmap, name: String): Attachment {
    val max = 1280f
    val s = minOf(1f, max / maxOf(b.width, b.height))
    val bm = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
    val out = ByteArrayOutputStream()
    bm.compress(Bitmap.CompressFormat.JPEG, 85, out)
    return Attachment("image/jpeg", out.toByteArray(), name)
}

/** Reads an image / PDF / text file picked through the system file picker (no storage permission needed). */
fun readAttachment(ctx: Context, uri: Uri): Attachment? {
    val cr = ctx.contentResolver
    val mime = cr.getType(uri) ?: "application/octet-stream"
    val name = cr.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: "file"
    val bytes = try { cr.openInputStream(uri)?.use { it.readBytes() } } catch (e: Exception) { null } ?: return null
    if (bytes.size > 15_000_000) return null
    if (mime.startsWith("image/")) {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        return bitmapAttachment(bmp, name)
    }
    val textExt = listOf(".txt", ".md", ".kt", ".java", ".py", ".html", ".css", ".js", ".json", ".csv", ".xml", ".log")
    val m = when {
        mime == "application/pdf" -> mime
        mime.startsWith("text/") -> "text/plain"
        textExt.any { name.lowercase().endsWith(it) } -> "text/plain"
        else -> return null
    }
    return Attachment(m, bytes, name)
}
