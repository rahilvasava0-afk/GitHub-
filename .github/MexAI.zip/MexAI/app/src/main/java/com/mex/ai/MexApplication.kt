package com.mex.ai

import android.app.Application

class MexApplication : Application() {
    lateinit var brain: Brain
    lateinit var voice: Voice

    override fun onCreate() {
        super.onCreate()
        brain = Brain(this)
        voice = Voice(this, brain.store)
    }
}
