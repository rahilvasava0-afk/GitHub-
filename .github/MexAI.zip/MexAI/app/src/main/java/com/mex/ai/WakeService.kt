package com.mex.ai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

/**
 * Foreground microphone service: listens for the wake word ("Mex"), answers, then keeps the
 * conversation going until you stay silent. Uses the system SpeechRecognizer (which may beep
 * and is battery-hungry - hence the visible notification and the on/off switch in Settings).
 */
class WakeService : Service() {
    companion object {
        @Volatile var running = false
        const val CHANNEL = "mex_wake"
    }

    private val main = Handler(Looper.getMainLooper())
    private var awaiting = false
    private lateinit var app: MexApplication

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        app = application as MexApplication
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Mex voice assistant", NotificationManager.IMPORTANCE_LOW))
        val open = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Mex AI sun rahi hai")
            .setContentText("Wake word: \"${app.brain.store.wakeWord}\"")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        if (!running) { running = true; loop() }
        return START_STICKY
    }

    private fun loop(delay: Long = 400) {
        main.postDelayed({
            if (!running) return@postDelayed
            app.voice.listen(
                onResult = { onHeard(it) },
                onFail = { e ->
                    awaiting = false
                    val wait = if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) 4000L else 700L
                    loop(wait)
                }
            )
        }, delay)
    }

    private fun onHeard(text: String) {
        val brain = app.brain
        if (!awaiting) {
            if (!brain.hasWake(text)) { loop(); return }
            val rest = brain.stripWake(text)
            if (rest.isBlank()) {
                awaiting = true
                app.voice.speak("Hmm Boss ❤️, bolo kya hua?") { loop() }
            } else process(rest)
        } else process(text)
    }

    private fun process(cmd: String) {
        thread {
            val out = app.brain.reply(cmd)
            main.post {
                awaiting = true  // keep the conversation open until the user goes quiet
                app.voice.speak(out) { loop() }
            }
        }
    }

    override fun onDestroy() {
        running = false
        app.voice.cancelListening()
        super.onDestroy()
    }
}
