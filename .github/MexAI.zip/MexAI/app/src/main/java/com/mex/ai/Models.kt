package com.mex.ai

data class Msg(val role: String, val text: String)

class Attachment(val mime: String, val bytes: ByteArray, val name: String)
