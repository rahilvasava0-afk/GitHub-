package com.mex.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Speech-to-text + text-to-speech. All public calls are safe from any thread. */
class Voice(private val ctx: Context, private val store: Store) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = mutableListOf<() -> Unit>()
    private var rec: SpeechRecognizer? = null

    var listening by mutableStateOf(false); private set
    var speaking by mutableStateOf(false); private set

    private fun ensureTts(then: () -> Unit) {
        if (ttsReady) { then(); return }
        pending.add(then)
        if (tts == null) {
            tts = TextToSpeech(ctx) { status ->
                main.post {
                    if (status == TextToSpeech.SUCCESS) {
                        ttsReady = true
                        applyVoice()
                        pending.toList().forEach { it() }
                    }
                    pending.clear()
                }
            }
        }
    }

    fun applyVoice() {
        val t = tts ?: return
        val loc = Locale.forLanguageTag(store.lang)
        t.language = loc
        t.setPitch(1.12f)
        t.setSpeechRate(1.0f)
        val voices = t.voices?.filter { it.locale.language == loc.language } ?: emptyList()
        val chosen = voices.firstOrNull { it.name == store.voiceName }
            ?: voices.firstOrNull { it.name.contains("female", true) }
        if (chosen != null) t.voice = chosen
    }

    fun loadVoices(cb: (List<String>) -> Unit) {
        main.post {
            ensureTts {
                val lang = Locale.forLanguageTag(store.lang).language
                cb(tts?.voices?.filter { it.locale.language == lang }?.map { it.name }?.sorted() ?: emptyList())
            }
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        main.post {
            ensureTts {
                applyVoice()
                val clean = text.replace(Regex("[\\p{So}*#`_]"), "").take(600)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { main.post { speaking = true } }
                    override fun onDone(id: String?) { main.post { speaking = false; onDone?.invoke() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { speaking = false; onDone?.invoke() } }
                    override fun onStop(id: String?, interrupted: Boolean) { main.post { speaking = false } }
                })
                tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "mex")
            }
        }
    }

    fun stopSpeaking() {
        main.post { tts?.stop(); speaking = false }
    }

    fun listen(onResult: (String) -> Unit, onFail: (Int) -> Unit) {
        main.post {
            tts?.stop(); speaking = false
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onFail(-1); return@post }
            rec?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) { listening = false; onFail(e) }
                override fun onResults(b: Bundle?) {
                    listening = false
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) onFail(SpeechRecognizer.ERROR_NO_MATCH) else onResult(t)
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            r.startListening(i)
        }
    }

    fun cancelListening() {
        main.post { rec?.destroy(); rec = null; listening = false }
    }
}
