package com.mex.ai

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp

/** Animated AI orb: calm idle pulse, faster pulse + wider rings while listening/speaking. */
@Composable
fun Orb(listening: Boolean, speaking: Boolean, dp: Dp, onClick: () -> Unit) {
    val active = listening || speaking
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        0.92f, if (active) 1.14f else 1.04f,
        infiniteRepeatable(tween(if (active) 650 else 2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 3000 else 9000, easing = LinearEasing)), label = "r")
    val core = if (speaking) NeonPink else if (listening) NeonPurple else NeonBlue
    Canvas(Modifier.size(dp).clickable(onClick = onClick)) {
        val c = center
        val half = this.size.minDimension / 2
        val r = half * 0.55f * pulse
        drawCircle(Brush.radialGradient(listOf(core.copy(.40f), Color.Transparent), c, half), radius = half)
        drawCircle(Brush.radialGradient(listOf(Color.White, core, NeonPurple, Color.Black), c, r), radius = r)
        rotate(rot, c) {
            val ring = r * 1.25f
            drawArc(NeonPurple, 0f, 110f, false, Offset(c.x - ring, c.y - ring), Size(ring * 2, ring * 2), style = Stroke(5f, cap = StrokeCap.Round))
            drawArc(NeonBlue, 180f, 80f, false, Offset(c.x - ring, c.y - ring), Size(ring * 2, ring * 2), style = Stroke(5f, cap = StrokeCap.Round))
        }
        rotate(-rot * 1.4f, c) {
            val ring = r * 1.5f
            drawArc(core.copy(.7f), 40f, 60f, false, Offset(c.x - ring, c.y - ring), Size(ring * 2, ring * 2), style = Stroke(3f, cap = StrokeCap.Round))
        }
    }
}
