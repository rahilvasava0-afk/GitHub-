package com.mex.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Thin REST client for the Gemini generateContent API (no SDK needed). Call off the main thread. */
object Gemini {
    fun generate(
        store: Store,
        system: String,
        history: List<Msg>,
        attachment: Attachment? = null,
        search: Boolean = false,
        maxTokens: Int = store.maxTokens
    ): String {
        val key = store.apiKey
        if (key.isBlank()) throw IllegalStateException("Gemini API key set nahi hai. Settings me API key daalo.")

        val contents = JSONArray()
        history.forEachIndexed { i, m ->
            val parts = JSONArray().put(JSONObject().put("text", m.text))
            if (attachment != null && i == history.lastIndex && m.role == "user") {
                parts.put(
                    JSONObject().put(
                        "inline_data", JSONObject()
                            .put("mime_type", attachment.mime)
                            .put("data", Base64.encodeToString(attachment.bytes, Base64.NO_WRAP))
                    )
                )
            }
            contents.put(JSONObject().put("role", m.role).put("parts", parts))
        }
        val gen = JSONObject()
            .put("temperature", store.temperature.toDouble())
            .put("maxOutputTokens", maxTokens)
        if (store.fastMode && store.model.contains("flash")) {
            gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", gen)
        if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${store.model}:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val text = (if (code < 400) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
            if (code >= 400) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(200) }
                throw IOException("Gemini error $code: $msg")
            }
            val cands = JSONObject(text).optJSONArray("candidates")
            if (cands == null || cands.length() == 0) throw IOException("Gemini ne koi jawab nahi diya (safety filter ho sakta hai).")
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                ?: throw IOException("Khaali jawab aaya. Max tokens badhao ya dobara try karo.")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            return sb.toString().trim().ifEmpty { throw IOException("Khaali jawab aaya.") }
        } finally {
            conn.disconnect()
        }
    }

    fun test(store: Store): String =
        generate(store, "Reply with exactly one word.", listOf(Msg("user", "Say OK")), null, false, 64)
}
