package com.mex.ai

import android.content.Context
import java.io.OutputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Shared "mind" used by both the UI and the background voice service. */
class Brain(ctx: Context) {
    val store = Store(ctx)
    val router = CommandRouter(ctx, store)
    val hist = CopyOnWriteArrayList<Msg>(store.history())

    private fun wakeRegex(): Regex {
        val w = store.wakeWord.ifBlank { "mex" }
        val variants = mutableListOf(w)
        if (w == "mex") variants += listOf("max", "mecs", "mags", "मेक्स", "मैक्स", "मेक्ष")
        val alt = variants.joinToString("|") { Regex.escape(it) }
        return Regex("(?<![\\p{L}])($alt)(?![\\p{L}])", RegexOption.IGNORE_CASE)
    }

    fun hasWake(text: String) = wakeRegex().containsMatchIn(text)

    /** Text after the wake word ("hey mex youtube kholo" -> "youtube kholo"). */
    fun stripWake(text: String): String {
        val m = wakeRegex().find(text) ?: return text.trim()
        return text.substring(m.range.last + 1).trim(' ', ',', '.', '!')
    }

    private fun needsSearch(t: String) = Regex(
        "weather|mausam|temperature|news|khabar|search|latest|score|price|rate|aaj ka|today|kal ka|trending",
        RegexOption.IGNORE_CASE
    ).containsMatchIn(t)

    fun systemPrompt(): String {
        val persona = when (store.persona) {
            "Funny" -> "Tum mazedaar, witty aur thodi shararati ho. Light jokes aur teasing karti ho, par helpful rehti ho."
            "Romantic" -> "Tum romantic, pyaar se baat karne wali aur sweet ho. Tasteful aur respectful rehti ho."
            "Professional" -> "Tum calm, precise aur professional JARVIS-style assistant ho."
            "Custom" -> store.customPersona.ifBlank { "Tum ek helpful assistant ho." }
            else -> "Tum caring, sweet, friendly girlfriend-style companion ho jo Boss ka dhyaan rakhti hai."
        }
        val lang = if (store.lang.startsWith("hi"))
            "Default me Hinglish (Roman Hindi + English mix) me jawab do. Agar Boss poori English me likhe to English me jawab do."
        else "Reply in English unless Boss writes in Hindi/Hinglish."
        val facts = store.facts().takeIf { it.isNotEmpty() }?.joinToString("; ")
            ?.let { "\nBoss ke baare me yaad rakhi hui baatein: $it" } ?: ""
        return "Tum Mex ho, ek female AI assistant jo Android app ke andar rehti hai (JARVIS jaisi smart). " +
            "User ko hamesha \"Boss\" bolo. $persona $lang " +
            "Voice ke liye jawab chhote aur natural rakho (1-3 sentences) jab tak Boss code ya detail na maange. " +
            "Robotic mat bano; emotion aur apnapan dikhao, thoda emoji use kar sakti ho. " +
            "Tum AI ho - agar Boss poochhe to sach bolo, insaan hone ka dawa mat karo. " +
            "Boss ki real-life zindagi, dosti aur sehat ka bhi khayal rakho. " +
            "Phone control commands (apps kholna, torch, volume etc.) app khud handle karta hai; unka natija tum claim mat karo." + facts
    }

    /** Blocking. Call from a background thread. */
    fun reply(userText: String, attachment: Attachment? = null): String {
        val clean = stripWake(userText)
        val msg = if (clean.isBlank() && attachment == null) {
            val g = "Hmm Boss ❤️, bolo kya hua?"
            hist.add(Msg("user", userText)); hist.add(Msg("model", g)); store.saveHistory(hist)
            return g
        } else clean.ifBlank { "Is file/photo me kya hai? Samjhao aur summary do." }

        val local = if (attachment == null) router.handle(msg) else null
        hist.add(Msg("user", if (attachment != null) "📎 ${attachment.name}: $msg" else msg))
        val out = local ?: try {
            val ctxMsgs = hist.takeLast(24).toMutableList()
            ctxMsgs[ctxMsgs.lastIndex] = Msg("user", msg)
            Gemini.generate(store, systemPrompt(), ctxMsgs, attachment, attachment == null && needsSearch(msg))
        } catch (e: Exception) {
            hist.removeAt(hist.lastIndex)
            return "Boss, ${e.message ?: "kuch gadbad ho gayi"}"
        }
        hist.add(Msg("model", out))
        store.saveHistory(hist)
        return out
    }

    fun clearHistory() { hist.clear(); store.saveHistory(hist) }

    /** Coding Studio call: no persona, no history. */
    fun coding(prompt: String, lang: String, mode: String): String {
        val sys = "You are an expert senior software engineer and Android architect. Task mode: $mode. " +
            "Primary language/stack: $lang. Return clean, complete, compilable code in fenced code blocks, followed by a SHORT explanation. " +
            "When generating a multi-file project or project structure, put EACH file in its own fenced block whose very first line is a comment " +
            "of the form `// FILE: path/relative/to/project/root/File.ext` (use `# FILE:` for Python/shell, `<!-- FILE: ... -->` for HTML). " +
            "When debugging, state the root cause first, then the fixed code. Do not use placeholders or pseudocode."
        return Gemini.generate(store, sys, listOf(Msg("user", prompt)), null, false, 8192)
    }
}

/** Parses fenced blocks with a FILE: marker and writes a ZIP. Returns number of files written. */
fun writeZipFromMarkdown(md: String, out: OutputStream): Int {
    val blocks = Regex("```[a-zA-Z0-9+#._-]*\\n([\\s\\S]*?)```").findAll(md).map { it.groupValues[1] }.toList()
    var n = 0
    ZipOutputStream(out).use { zip ->
        blocks.forEachIndexed { idx, b ->
            val first = b.lineSequence().firstOrNull() ?: ""
            val m = Regex("FILE:\\s*([^\\s>]+)").find(first)
            val path = m?.groupValues?.get(1)?.trimStart('/')?.replace("..", "_") ?: "snippet_${idx + 1}.txt"
            val body = if (m != null) b.substringAfter('\n', "") else b
            zip.putNextEntry(ZipEntry(path))
            zip.write(body.toByteArray())
            zip.closeEntry()
            n++
        }
        if (n == 0) {
            zip.putNextEntry(ZipEntry("output.md")); zip.write(md.toByteArray()); zip.closeEntry(); n = 1
        }
    }
    return n
}
