package com.mex.ai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val langs = listOf("Kotlin (Android)", "Java (Android)", "HTML/CSS/JavaScript", "Python", "Kotlin", "Java")
private val modes = listOf("Generate code", "Debug error", "Explain code", "Fix build error", "Full project structure")

@Composable
fun CodingScreen(vm: MexVM) {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(langs[0]) }
    var mode by remember { mutableStateOf(modes[0]) }
    var prompt by remember { mutableStateOf("") }
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFFE6EDF3))

    val saveTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(vm.codeOut.toByteArray()) } }
    }
    val saveZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let {
            val n = ctx.contentResolver.openOutputStream(it)?.use { o -> writeZipFromMarkdown(vm.codeOut, o) } ?: 0
            Toast.makeText(ctx, "ZIP me $n file(s) save hui", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("💻 Coding Studio", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Picker("Lang", langs, lang) { lang = it }
            Picker("Mode", modes, mode) { mode = it }
        }
        OutlinedTextField(
            prompt, { prompt = it }, Modifier.fillMaxWidth(), minLines = 6, maxLines = 14,
            label = { Text("Prompt / code / error log yahan paste karo") },
            textStyle = mono, visualTransformation = codeTransformation
        )
        Button(onClick = { vm.code(prompt, lang, mode) }, enabled = !vm.codeBusy && prompt.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text(if (vm.codeBusy) "Mex likh rahi hai…" else "✨ Run with Gemini")
        }
        if (vm.codeOut.isNotBlank()) {
            Glass(Modifier.fillMaxWidth()) {
                SelectionContainer {
                    Text(highlight(vm.codeOut), style = mono, modifier = Modifier.horizontalScroll(rememberScrollState()))
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("code", vm.codeOut))
                    Toast.makeText(ctx, "Copy ho gaya", Toast.LENGTH_SHORT).show()
                }) { Text("📋 Copy") }
                OutlinedButton(onClick = { saveTxt.launch("mex_output.txt") }) { Text("💾 Save file") }
                OutlinedButton(onClick = { saveZip.launch("mex_project.zip") }) { Text("📦 Export ZIP") }
            }
            Text(
                "ZIP tab banta hai jab output me `// FILE: path` wale code blocks hon (\"Full project structure\" mode).",
                fontSize = 11.sp, color = Color.White.copy(.5f)
            )
        }
    }
}
