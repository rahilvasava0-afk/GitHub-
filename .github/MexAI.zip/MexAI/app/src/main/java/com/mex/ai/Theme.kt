package com.mex.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val NeonBlue = Color(0xFF00D4FF)
val NeonPurple = Color(0xFF9B5CFF)
val NeonPink = Color(0xFFFF4FD8)
val accents = listOf("Neon Blue" to NeonBlue, "Purple" to NeonPurple, "Pink" to NeonPink)
val bgBrush = Brush.verticalGradient(listOf(Color.Black, Color(0xFF0A0620), Color.Black))

@Composable
fun MexTheme(accent: Color, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent, secondary = NeonPurple, background = Color.Black,
            surface = Color(0xFF0A0A12), onBackground = Color.White, onSurface = Color.White,
            surfaceVariant = Color(0xFF14141F), onPrimary = Color.Black
        ),
        content = content
    )
}

/** Glassmorphism card. */
@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Brush.linearGradient(listOf(NeonBlue.copy(.5f), NeonPurple.copy(.5f))), shape)
            .padding(14.dp),
        content = content
    )
}
