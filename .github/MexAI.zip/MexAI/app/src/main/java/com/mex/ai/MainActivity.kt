package com.mex.ai

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}.launch(perms.toTypedArray())
        setContent {
            val vm: MexVM = viewModel()
            MexRoot(vm)
        }
    }
}

private val tabs = listOf("🏠" to "Home", "💬" to "Chat", "💻" to "Coding", "📱" to "Apps", "⚙️" to "Settings")

@Composable
fun MexRoot(vm: MexVM) {
    MexTheme(accents[vm.accent.coerceIn(0, accents.lastIndex)].second) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        Scaffold(
            modifier = Modifier.background(bgBrush),
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xE605050A)) {
                    tabs.forEachIndexed { i, (emoji, label) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Text(emoji, fontSize = 20.sp) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(vm) { tab = 1 }
                    1 -> ChatScreen(vm)
                    2 -> CodingScreen(vm)
                    3 -> AppsScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}
