package com.mex.ai

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppsScreen(vm: MexVM) {
    val ctx = LocalContext.current
    val apps = remember { vm.brain.router.launchableApps() }
    val notes = remember { mutableStateListOf<String>().also { it.addAll(vm.store.notes()) } }
    var search by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val info = remember { vm.brain.router.deviceInfo() }
    val shown = apps.filter { it.first.contains(search, true) }

    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("📱 Apps & Tools", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary) }
        item { Glass(Modifier.fillMaxWidth()) { Text("Device info", color = NeonBlue); Text(info, color = Color.White, fontSize = 13.sp) } }
        item {
            Glass(Modifier.fillMaxWidth()) {
                Text("📝 Personal notes", color = NeonBlue)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(note, { note = it }, Modifier.weight(1f), placeholder = { Text("Naya note…") }, singleLine = true)
                    TextButton(onClick = {
                        if (note.isNotBlank()) { notes.add(0, note.trim()); vm.store.saveNotes(notes); note = "" }
                    }) { Text("Add") }
                }
                notes.forEachIndexed { i, n ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("• $n", color = Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        TextButton(onClick = { notes.removeAt(i); vm.store.saveNotes(notes) }) { Text("✕") }
                    }
                }
            }
        }
        item {
            OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), placeholder = { Text("🔍 App dhundo…") }, singleLine = true)
        }
        items(shown, key = { it.second }) { (label, pkg) ->
            Glass(Modifier.fillMaxWidth().clickable {
                if (!vm.brain.router.openApp(pkg)) Toast.makeText(ctx, "App nahi khul paya", Toast.LENGTH_SHORT).show()
            }) { Text(label, color = Color.White) }
        }
    }
}
