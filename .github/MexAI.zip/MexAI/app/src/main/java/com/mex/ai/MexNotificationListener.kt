package com.mex.ai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

/** Keeps the last few notifications in memory (never written to disk) so Mex can read them out. */
class MexNotificationListener : NotificationListenerService() {
    companion object {
        val recent = CopyOnWriteArrayList<String>()
        @Volatile var connected = false
    }

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)
        val text = e.getCharSequence(Notification.EXTRA_TEXT)
        if (title == null && text == null) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ex: Exception) { sbn.packageName }
        recent.add(0, "$app: ${title ?: ""} ${text ?: ""}".trim())
        while (recent.size > 15) recent.removeAt(recent.size - 1)
    }
}
