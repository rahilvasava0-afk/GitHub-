package com.mex.ai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun ChatScreen(vm: MexVM) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(Unit) { vm.reload() }
    LaunchedEffect(vm.messages.size) { if (vm.messages.isNotEmpty()) list.animateScrollToItem(vm.messages.size - 1) }

    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { b ->
        if (b != null) { vm.send(input.ifBlank { "Is photo me kya hai? Batao." }, bitmapAttachment(b, "camera.jpg")); input = "" }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val att = readAttachment(ctx, uri)
            if (att == null) Toast.makeText(ctx, "Ye file type ya size support nahi (image/PDF/text, max 15MB).", Toast.LENGTH_LONG).show()
            else { vm.send(input.ifBlank { "Isko summarize/explain karo." }, att); input = "" }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        LazyColumn(Modifier.weight(1f), state = list, verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            if (vm.messages.isEmpty()) item { Text("Boss, kuch bhi poochho… 💜", color = Color.White.copy(.5f)) }
            items(vm.messages) { Bubble(it) }
            if (vm.busy) item { Text("Mex soch rahi hai…", color = Color.White.copy(.5f)) }
        }
        Row(Modifier.padding(bottom = 4.dp)) {
            TextButton(onClick = { cam.launch(null) }) { Text("📸 Camera AI") }
            TextButton(onClick = { pick.launch("*/*") }) { Text("📎 File/Photo") }
            TextButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()
                if (t.isNullOrBlank()) Toast.makeText(ctx, "Clipboard khaali hai", Toast.LENGTH_SHORT).show()
                else vm.send("Ye clipboard text samjhao / summarize karo:\n$t")
            }) { Text("📋 Clipboard") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
            IconButtonText("🎤") { vm.toggleVoice() }
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message Mex…") },
                maxLines = 4, shape = RoundedCornerShape(24.dp)
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.send(input); input = "" }, enabled = !vm.busy) { Text("➤") }
        }
    }
}

@Composable
private fun IconButtonText(t: String, onClick: () -> Unit) = TextButton(onClick = onClick) { Text(t) }

@Composable
fun Bubble(m: Msg) {
    val user = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 310.dp).clip(RoundedCornerShape(18.dp))
                .background(if (user) MaterialTheme.colorScheme.primary.copy(.25f) else Color.White.copy(.07f))
                .padding(12.dp)
        ) { SelectionContainer { Text(m.text, color = Color.White) } }
    }
}
