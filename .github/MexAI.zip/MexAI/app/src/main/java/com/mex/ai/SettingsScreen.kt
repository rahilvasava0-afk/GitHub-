package com.mex.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Glass(Modifier.fillMaxWidth()) {
        Text(title, color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun SettingsScreen(vm: MexVM) {
    val ctx = LocalContext.current
    val store = vm.store
    val scope = rememberCoroutineScope()
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun open(i: Intent) = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Ye screen is phone par nahi mili") }

    var key by remember { mutableStateOf(store.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(store.model) }
    var temp by remember { mutableFloatStateOf(store.temperature) }
    var tokens by remember { mutableFloatStateOf(store.maxTokens.toFloat()) }
    var fast by remember { mutableStateOf(store.fastMode) }
    var status by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf(store.lang) }
    var voiceName by remember { mutableStateOf(store.voiceName) }
    var voices by remember { mutableStateOf(listOf<String>()) }
    var wake by remember { mutableStateOf(store.wakeWord) }
    var wakeOn by remember { mutableStateOf(WakeService.running || store.wakeEnabled) }
    var persona by remember { mutableStateOf(store.persona) }
    var custom by remember { mutableStateOf(store.customPersona) }
    var keep by remember { mutableStateOf(store.keepHistory) }
    var facts by remember { mutableStateOf(store.facts()) }
    var tick by remember { mutableIntStateOf(0) }
    var tx by remember { mutableStateOf("500") }
    var ty by remember { mutableStateOf("1000") }
    LaunchedEffect(lang) { vm.voice.loadVoices { voices = it } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("⚙️ Settings", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)

        Section("🧠 Gemini API") {
            OutlinedTextField(
                key, { key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") } }
            )
            Text("Key encrypted storage (AES-256, Android Keystore) me save hoti hai. Free key: aistudio.google.com", fontSize = 11.sp, color = Color.White.copy(.5f))
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
            Picker("Quick pick", listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-2.0-flash"), model) { model = it }
            Text("Temperature: %.1f".format(temp), color = Color.White)
            Slider(temp, { temp = it }, valueRange = 0f..2f, onValueChangeFinished = { store.temperature = temp })
            Text("Max tokens: ${tokens.toInt()}", color = Color.White)
            Slider(tokens, { tokens = it }, valueRange = 256f..8192f, onValueChangeFinished = { store.maxTokens = tokens.toInt() })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(fast, { fast = it; store.fastMode = it })
                Spacer(Modifier.width(8.dp)); Text("Fast replies (thinking off, flash models)", color = Color.White, fontSize = 13.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { store.apiKey = key.trim(); store.model = model.trim(); toast("Saved") }) { Text("Save") }
                OutlinedButton(onClick = {
                    store.apiKey = key.trim(); store.model = model.trim(); status = "Testing…"
                    scope.launch(Dispatchers.IO) {
                        val r = try { "✅ Connected: " + Gemini.test(store) } catch (e: Exception) { "❌ ${e.message}" }
                        withContext(Dispatchers.Main) { status = r }
                    }
                }) { Text("Test connection") }
            }
            if (status.isNotBlank()) Text(status, color = Color.White, fontSize = 13.sp)
        }

        Section("🗣 Voice & language") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Picker("Language", listOf("hi-IN", "en-IN", "en-US"), lang) { lang = it; store.lang = it; voiceName = ""; store.voiceName = "" }
                Picker("Voice", listOf("(auto female)") + voices, voiceName.ifBlank { "(auto female)" }) {
                    voiceName = if (it.startsWith("(")) "" else it; store.voiceName = voiceName
                }
            }
            OutlinedButton(onClick = { vm.voice.speak("Hmm Boss, main Mex hoon. Aapki awaaz kaisi lag rahi hai?") }) { Text("▶ Test voice") }
            Text("Zyada natural voices ke liye phone ki Text-to-speech settings me Google voices download karo.", fontSize = 11.sp, color = Color.White.copy(.5f))
        }

        Section("🎙 Wake word & background assistant") {
            OutlinedTextField(wake, { wake = it }, Modifier.fillMaxWidth(), label = { Text("Wake word") }, singleLine = true)
            Button(onClick = { store.wakeWord = wake; toast("Wake word: ${store.wakeWord}") }) { Text("Save wake word") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(wakeOn, { on ->
                    if (on) {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            toast("Pehle mic permission do")
                        } else {
                            store.wakeEnabled = true; wakeOn = true
                            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
                        }
                    } else {
                        store.wakeEnabled = false; wakeOn = false
                        ctx.stopService(Intent(ctx, WakeService::class.java))
                    }
                })
                Spacer(Modifier.width(8.dp)); Text("Background wake-word listening", color = Color.White, fontSize = 13.sp)
            }
            OutlinedButton(onClick = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("🔋 Battery optimization settings") }
            Text("Mic use hone par Android notification dikhata hai. Battery zyada lag sakti hai.", fontSize = 11.sp, color = Color.White.copy(.5f))
        }

        Section("💞 AI personality") {
            Picker("Mode", listOf("Girlfriend", "Funny", "Romantic", "Professional", "Custom"), persona) { persona = it; store.persona = it }
            if (persona == "Custom") {
                OutlinedTextField(custom, { custom = it; store.customPersona = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text("Describe personality") })
            }
        }

        Section("🧩 Memory") {
            Text("Mex ko \"yaad rakho ...\" bolo, wo yahan save hoga.", fontSize = 12.sp, color = Color.White.copy(.6f))
            facts.forEachIndexed { i, f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("• $f", color = Color.White, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    TextButton(onClick = { val l = facts.toMutableList(); l.removeAt(i); store.saveFacts(l); facts = l }) { Text("✕") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { store.saveFacts(emptyList()); facts = emptyList() }) { Text("Clear memory") }
                OutlinedButton(onClick = { vm.clearHistory(); toast("Chat history clear") }) { Text("Clear chat") }
            }
        }

        Section("🤖 Automation & permissions") {
            val accOn = MexAccessibilityService.instance != null
            val notifOn = MexNotificationListener.connected
            Text("Accessibility: ${if (accOn) "ON ✅" else "OFF ❌"}  |  Notification access: ${if (notifOn) "ON ✅" else "OFF ❌"}  |  Write settings: ${if (Settings.System.canWrite(ctx)) "ON ✅" else "OFF ❌"}${if (tick >= 0) "" else ""}", color = Color.White, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Accessibility") }
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text("Notifications") }
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }) { Text("System settings") }
                OutlinedButton(onClick = { tick++ }) { Text("↻ Refresh") }
            }
            Text("Test automation", color = Color.White, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(tx, { tx = it }, Modifier.weight(1f), label = { Text("x") }, singleLine = true)
                OutlinedTextField(ty, { ty = it }, Modifier.weight(1f), label = { Text("y") }, singleLine = true)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.send("tap ${tx.filter { it.isDigit() }} ${ty.filter { it.isDigit() }}") }) { Text("Tap") }
                OutlinedButton(onClick = { vm.send("scroll down") }) { Text("Scroll ↓") }
                OutlinedButton(onClick = { vm.send("scroll up") }) { Text("Scroll ↑") }
                OutlinedButton(onClick = { vm.send("back jao") }) { Text("Back") }
            }
            Text("Accessibility sirf tab kaam karti hai jab aap command do. Android secure screens (banking, password) par block kar sakta hai.", fontSize = 11.sp, color = Color.White.copy(.5f))
        }

        Section("🎨 Theme") {
            Picker("Accent", accents.map { it.first }, accents[vm.accent].first) { n ->
                val i = accents.indexOfFirst { it.first == n }; vm.accent = i; store.accent = i
            }
        }

        Section("🔒 Privacy") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(keep, { keep = it; store.keepHistory = it; if (!it) store.saveHistory(emptyList()) })
                Spacer(Modifier.width(8.dp)); Text("Chat history device par save karo", color = Color.White, fontSize = 13.sp)
            }
            Text("Sab data (API key, memory, notes, history) sirf is phone me encrypted rehta hai. Baat karte waqt aapka text/photo/file Google Gemini API ko bheja jata hai. Notification contents disk par save nahi hote.", fontSize = 12.sp, color = Color.White.copy(.6f))
        }

        Section("ℹ️ About Mex AI") {
            Text("Mex AI v1.0 — Gemini-powered Android voice assistant.\nPhone control sirf Android ke allowed APIs se hota hai.", color = Color.White, fontSize = 13.sp)
        }
        Spacer(Modifier.height(20.dp))
    }
}
