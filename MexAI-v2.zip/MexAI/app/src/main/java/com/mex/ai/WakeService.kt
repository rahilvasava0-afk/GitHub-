package com.mex.ai

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class WakeService : Service() {
    private var porcupine: PorcupineManager? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var speaker: Speaker
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        speaker = Speaker(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(this, 1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        Bus.serviceOn = true
        startWake()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mex", "Mex AI", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "mex")
            .setContentTitle("Mex AI")
            .setContentText("Mex sun rahi hai…")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun startWake() {
        if (porcupine != null) return
        val key = Prefs.picovoice(this)
        if (key.isBlank()) { fail("Settings mein Picovoice key daalo"); return }
        try {
            val hasMex = assets.list("")?.contains("mex.ppn") == true
            val b = PorcupineManager.Builder().setAccessKey(key).setSensitivity(0.7f)
            if (hasMex) b.setKeywordPath("mex.ppn") else b.setKeyword(Porcupine.BuiltInKeyword.JARVIS)
            porcupine = b.build(this) { _ -> main.post { onWake() } }
            porcupine?.start()
            Bus.status = "Sun rahi hoon… bolo \"${if (hasMex) "Mex" else "Jarvis"}\""
        } catch (e: Exception) {
            fail("Porcupine error: ${e.message}")
        }
    }

    private fun fail(msg: String) {
        Bus.status = msg
        stopSelf()
    }

    private fun onWake() {
        if (busy) return
        busy = true
        try { porcupine?.stop() } catch (_: Exception) {}
        Bus.status = "Hmm Boss ❤️, bolo kya hua?"
        speaker.speak("Hmm Boss, bolo kya hua?") { listen() }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { reply("Boss, is phone par speech recognition available nahi hai."); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { Bus.status = "Sun rahi hoon, bolo…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { endTurn() }
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) endTurn() else handle(t)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        recognizer?.startListening(i)
    }

    private fun handle(text: String) {
        Bus.messages.add(Msg(true, text))
        Bus.status = "Soch rahi hoon…"
        scope.launch {
            val r = Commands.tryHandle(this@WakeService, text)
                ?: GeminiClient.ask(Prefs.gemini(this@WakeService), text)
            reply(r)
        }
    }

    private fun reply(text: String) {
        Bus.messages.add(Msg(false, text))
        speaker.speak(text) { endTurn() }
    }

    private fun endTurn() {
        recognizer?.destroy()
        recognizer = null
        busy = false
        try { porcupine?.start() } catch (_: Exception) {}
        Bus.status = "Sun rahi hoon… bolo wake word"
    }

    override fun onDestroy() {
        scope.cancel()
        try { porcupine?.stop(); porcupine?.delete() } catch (_: Exception) {}
        porcupine = null
        recognizer?.destroy()
        speaker.shutdown()
        Bus.serviceOn = false
        if (!Bus.status.contains("key") && !Bus.status.contains("error")) Bus.status = "Band hai"
        super.onDestroy()
    }

    companion object {
        fun start(c: Context) { ContextCompat.startForegroundService(c, Intent(c, WakeService::class.java)) }
        fun stop(c: Context) { c.stopService(Intent(c, WakeService::class.java)) }
    }
}
