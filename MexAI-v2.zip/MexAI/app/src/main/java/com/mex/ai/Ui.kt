package com.mex.ai

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Cyan = Color(0xFF00E5FF)
private val Pink = Color(0xFFFF4081)

@Composable
fun MexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Pink,
            background = Color(0xFF050B14), surface = Color(0xFF0B1626),
            onBackground = Color.White, onSurface = Color.White, onPrimary = Color.Black
        ),
        content = content
    )
}

private data class Tab(val name: String, val icon: ImageVector)

@Composable
fun MexApp(onToggle: () -> Unit) {
    val tabs = listOf(
        Tab("Home", Icons.Filled.Home), Tab("Chat", Icons.Filled.Chat), Tab("Coding", Icons.Filled.Code),
        Tab("Apps", Icons.Filled.Apps), Tab("Settings", Icons.Filled.Settings)
    )
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Icon(t.icon, contentDescription = t.name) }, label = { Text(t.name) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(onToggle)
                1 -> ChatScreen()
                2 -> CodingScreen()
                3 -> AppsScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onToggle: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(0.85f, 1.1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "r")
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Canvas(Modifier.size(240.dp)) {
            val c = center
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.5f), Color.Transparent), c, r * pulse), r * pulse, c)
            drawCircle(Cyan, r * 0.55f, c, style = Stroke(4f))
            rotate(rot, c) {
                drawArc(Pink, 0f, 90f, false, Offset(c.x - r * 0.7f, c.y - r * 0.7f), Size(r * 1.4f, r * 1.4f), style = Stroke(6f, cap = StrokeCap.Round))
            }
            drawCircle(Cyan.copy(alpha = 0.25f), r * 0.3f * pulse, c)
        }
        Text("MEX", fontSize = 32.sp, color = Cyan, modifier = Modifier.padding(top = 16.dp))
        Text(Bus.status, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
        Bus.messages.lastOrNull { !it.fromUser }?.let { Text(it.text, fontSize = 14.sp, color = Color.Gray) }
        Button(onClick = onToggle, modifier = Modifier.padding(top = 24.dp)) {
            Text(if (Bus.serviceOn) "Mex ko band karo" else "Mex ko jagao")
        }
    }
}

@Composable
private fun Bubble(m: Msg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(color = if (m.fromUser) Cyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(14.dp)) {
            Text(m.text, Modifier.padding(10.dp).widthIn(max = 300.dp))
        }
    }
}

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(Bus.messages.size) { if (Bus.messages.isNotEmpty()) list.animateScrollToItem(Bus.messages.size - 1) }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Bus.messages) { Bubble(it) }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Mex se likhkar bolo…") }, maxLines = 3)
            IconButton(enabled = !loading && input.isNotBlank(), onClick = {
                val q = input.trim()
                input = ""
                Bus.messages.add(Msg(true, q))
                loading = true
                scope.launch {
                    val r = Commands.tryHandle(ctx, q) ?: GeminiClient.ask(Prefs.gemini(ctx), q)
                    Bus.messages.add(Msg(false, r))
                    loading = false
                }
            }) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Cyan) }
        }
    }
}

@Composable
fun CodingScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val sys = "Tum ek expert programmer ho. Pehle code do (code block mein), phir 2-3 line ka chhota explanation Hinglish mein."
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Coding Studio", fontSize = 22.sp, color = Cyan)
        OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), placeholder = { Text("Kya banana hai? (jaise: Kotlin mein calculator)") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !loading && input.isNotBlank(), onClick = {
                loading = true; result = "Soch rahi hoon…"
                scope.launch { result = GeminiClient.ask(Prefs.gemini(ctx), input, sys, false); loading = false }
            }) { Text("Banao") }
            OutlinedButton(enabled = result.isNotBlank(), onClick = { clipboard.setText(AnnotatedString(result)) }) {
                Icon(Icons.Filled.ContentCopy, null); Text(" Copy")
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(result, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }
    }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val apps = remember { Commands.launchableApps(ctx) }
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("App dhundho…") }, singleLine = true)
        LazyColumn {
            items(apps.filter { it.first.contains(q, ignoreCase = true) }) { app ->
                Text(app.first, Modifier.fillMaxWidth().clickable { Commands.openApp(ctx, app.second) }.padding(vertical = 14.dp))
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var gem by remember { mutableStateOf(Prefs.gemini(ctx)) }
    var pico by remember { mutableStateOf(Prefs.picovoice(ctx)) }
    var saved by remember { mutableStateOf(false) }
    val hasMex = remember { ctx.assets.list("")?.contains("mex.ppn") == true }
    val pkg = Uri.parse("package:" + ctx.packageName)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 22.sp, color = Cyan)
        OutlinedTextField(gem, { gem = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(pico, { pico = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Picovoice AccessKey") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Button(onClick = { Prefs.save(ctx, gem, pico); saved = true }) { Text(if (saved) "Save ho gaya ✓" else "Save karo") }
        Text(if (hasMex) "Wake word: \"Mex\" (mex.ppn mili)" else "Wake word: \"Jarvis\" (mex.ppn nahi mili, isliye default)", fontSize = 13.sp, color = Color.Gray)
        HorizontalDivider()
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Accessibility service on karo")
        }
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Display over other apps allow karo")
        }
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Battery ko Unrestricted karo (App info)")
        }
    }
}
