package com.mex.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

/** Phone control: app kholna, YouTube par gaana, call dial, Home/Back. Match na ho to null (Gemini jawab dega). */
object Commands {
    private val openSet = setOf("open", "kholo", "khol", "launch", "खोलो", "खोल", "ओपन")
    private val playSet = setOf("play", "bajao", "bajaao", "baja", "chalao", "chala", "sunao", "बजाओ", "बजा", "चलाओ", "चला", "सुनाओ", "प्ले")
    private val callSet = setOf("call", "dial", "phone", "कॉल", "फोन")
    private val stop = setOf(
        "do", "de", "kar", "karo", "दो", "दे", "कर", "करो", "youtube", "यूट्यूब", "music", "म्यूज़िक", "पर", "par", "pe",
        "mein", "में", "ko", "को", "ka", "का", "ke", "के", "ki", "की", "please", "plz", "mex", "मेक्स",
        "gaana", "gaane", "gana", "गाना", "गाने", "song", "songs", "ek", "एक", "app", "ऐप"
    )
    private val aliases = mapOf(
        "वॉट्सऐप" to "whatsapp", "व्हाट्सएप" to "whatsapp", "यूट्यूब" to "youtube", "कैमरा" to "camera",
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery", "क्रोम" to "chrome",
        "इंस्टाग्राम" to "instagram", "मैप्स" to "maps", "जीमेल" to "gmail"
    )

    fun tryHandle(ctx: Context, raw: String): String? = try { handle(ctx, raw) } catch (e: Exception) { "Boss, ye kaam nahi ho paaya." }

    private fun handle(ctx: Context, raw: String): String? {
        val tokens = raw.lowercase().trim().split(Regex("\\s+")).map { aliases[it] ?: it }

        if (tokens.size <= 4) nav(tokens)?.let { return it }

        if (tokens.any { it in callSet }) {
            val num = Regex("\\+?\\d[\\d\\s-]{6,}\\d").find(raw)?.value?.filter { it.isDigit() || it == '+' }
            if (num != null) {
                start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
                return "Ok Boss, $num dial kar rahi hoon."
            }
        }

        if (tokens.any { it in openSet }) {
            val q = tokens.filter { it !in openSet && it !in stop }.joinToString(" ")
            findApp(ctx, q)?.let { openApp(ctx, it.second); return "Ok Boss, ${it.first} khol rahi hoon." }
        }

        if (tokens.any { it in playSet }) {
            val q = tokens.filter { it !in playSet && it !in stop }.joinToString(" ")
            if (q.isNotBlank()) { playYoutube(ctx, q); return "Ok Boss, $q YouTube par laga rahi hoon." }
        }
        return null
    }

    private fun nav(t: List<String>): String? {
        val (action, reply) = when {
            t.any { it == "home" || it == "होम" } -> AccessibilityService.GLOBAL_ACTION_HOME to "Home screen par, Boss."
            t.any { it in setOf("back", "wapas", "वापस", "पीछे", "peeche") } -> AccessibilityService.GLOBAL_ACTION_BACK to "Wapas, Boss."
            t.any { it in setOf("recent", "recents", "रीसेंट") } -> AccessibilityService.GLOBAL_ACTION_RECENTS to "Recent apps, Boss."
            t.any { it in setOf("notification", "notifications", "नोटिफिकेशन") } -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS to "Notifications khol di, Boss."
            Build.VERSION.SDK_INT >= 28 && t.any { it == "screenshot" || it == "स्क्रीनशॉट" } ->
                AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT to "Screenshot le liya, Boss."
            else -> return null
        }
        val svc = MexAccessibilityService.instance ?: return "Boss, pehle Settings mein Accessibility service on karo."
        svc.performGlobalAction(action)
        return reply
    }

    fun launchableApps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    private fun findApp(ctx: Context, q: String): Pair<String, String>? {
        if (q.isBlank()) return null
        val apps = launchableApps(ctx)
        return apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.firstOrNull { it.first.lowercase().contains(q) }
            ?: apps.firstOrNull { q.contains(it.first.lowercase()) }
    }

    fun openApp(ctx: Context, pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { start(ctx, it) }
    }

    private fun playYoutube(ctx: Context, q: String) {
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        try { start(ctx, i) } catch (e: Exception) {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        }
    }

    private fun start(ctx: Context, i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
