package com.mex.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    // Model naam badalna ho to sirf yahan badlo
    private const val MODEL = "gemini-2.5-flash"

    const val PERSONA = "Tum Mex ho, ek female JARVIS jaisi voice assistant. User ko hamesha 'Boss' bulao. " +
        "Hinglish (Roman script) mein bolo. Jawab chhote aur natural rakho, 1 se 3 vaakya. " +
        "Emoji, markdown ya bullet points mat use karo kyunki jawab bolke sunaya jayega."

    private val history = mutableListOf<Pair<String, String>>()

    private fun turn(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    suspend fun ask(
        key: String,
        prompt: String,
        system: String = PERSONA,
        useHistory: Boolean = true
    ): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "Boss, pehle Settings mein Gemini key daalo."
        try {
            val contents = JSONArray()
            if (useHistory) history.takeLast(10).forEach { contents.put(turn(it.first, it.second)) }
            contents.put(turn("user", prompt))
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", key)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) return@withContext "Boss, Gemini error $code aaya. Key check karo."

            val reply = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text").trim()
            if (useHistory) {
                history.add("user" to prompt)
                history.add("model" to reply)
            }
            reply
        } catch (e: Exception) {
            "Boss, internet ya key mein dikkat hai."
        }
    }
}
