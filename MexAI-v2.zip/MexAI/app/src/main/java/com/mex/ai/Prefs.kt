package com.mex.ai

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("mex", Context.MODE_PRIVATE)
    fun gemini(c: Context): String = sp(c).getString("gemini", "") ?: ""
    fun picovoice(c: Context): String = sp(c).getString("pico", "") ?: ""
    fun save(c: Context, g: String, p: String) {
        sp(c).edit().putString("gemini", g.trim()).putString("pico", p.trim()).apply()
    }
}

data class Msg(val fromUser: Boolean, val text: String)

/** UI aur service ke beech shared state */
object Bus {
    val messages = mutableStateListOf<Msg>()
    var status by mutableStateOf("Band hai")
    var serviceOn by mutableStateOf(false)
}
