package com.mex.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Speaker(ctx: Context) {
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private var pending: Pair<String, (() -> Unit)?>? = null
    private var callback: (() -> Unit)? = null

    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
            ready = true
            // en-IN Hinglish (Roman) ko achhe se padhta hai. Chaho to Locale("hi","IN") try karo.
            this.tts.language = Locale("en", "IN")
            this.tts.setPitch(1.15f)
            pending?.let { speak(it.first, it.second); pending = null }
        }
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish()
            override fun onError(utteranceId: String?) = finish()
        })
    }

    private fun finish() {
        main.post {
            val cb = callback
            callback = null
            cb?.invoke()
        }
    }

    fun speak(text: String, done: (() -> Unit)? = null) {
        if (!ready) { pending = text to done; return }
        callback = done
        val clean = text.replace("\n", ". ")
            .replace(Regex("[*#`_]"), "")
            .replace(Regex("[^\\p{L}\\p{N}\\p{P}\\p{Z}]"), "")
            .ifBlank { "Ji Boss." }
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "mex")
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
