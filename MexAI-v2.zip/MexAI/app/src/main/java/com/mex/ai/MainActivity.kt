package com.mex.ai

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) WakeService.start(this)
        else Bus.status = "Mic permission chahiye"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MexTheme { MexApp(onToggle = { toggle() }) } }
    }

    private fun toggle() {
        if (Bus.serviceOn) {
            WakeService.stop(this)
        } else {
            val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            perms.launch(need.toTypedArray())
        }
    }
}
